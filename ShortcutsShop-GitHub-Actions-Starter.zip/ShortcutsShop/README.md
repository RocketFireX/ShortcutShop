# Shortcuts Shop

A native SwiftUI Frutiger Aero-inspired storefront starter for Apple Shortcuts.

## Build an IPA with GitHub Actions (no Mac required)

1. Create a **public** GitHub repository (public repositories are the easiest way to use standard GitHub-hosted runners without consuming private-repository minutes).
2. Upload the contents of this folder to the repository root.
3. Open **Actions** and allow workflows if GitHub asks.
4. The workflow runs on pushes to `main`, or start it manually from **Actions → Build Shortcuts Shop IPA → Run workflow**.
5. Open the completed workflow run and download the `ShortcutsShop-unsigned-IPA` artifact.

## Important: unsigned IPA

This workflow creates an **unsigned** IPA. It proves the app can be compiled and packaged, but it is not ready to install directly on an iPhone. iOS requires a valid signature and provisioning profile for installation. Do not put Apple certificates or provisioning profiles in a public repository.

## Add real shortcuts

The current catalog is demo content. It intentionally does not pretend to contain working shortcuts. Export your own `.shortcut` files from the Shortcuts app, add them to the Xcode project as bundled resources, and implement a share/open flow before advertising an item as downloadable.

## App identity

- Display name: Shortcuts Shop
- Bundle identifier: `org.studsup.shortcutsshop`
- Minimum deployment target: iOS 17.0
