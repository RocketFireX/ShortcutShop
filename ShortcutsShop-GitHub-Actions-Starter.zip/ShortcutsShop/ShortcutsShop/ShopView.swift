import SwiftUI
import UniformTypeIdentifiers

struct ShortcutItem: Identifiable {
    let id: String
    let name: String
    let category: String
    let description: String
    let symbol: String
    let tint: Color
    let filename: String
}

private let catalog: [ShortcutItem] = [
    .init(id: "morning", name: "Morning Dashboard", category: "Productivity",
          description: "A clean starting point for your day.", symbol: "sun.max.fill",
          tint: Color(red: 0.98, green: 0.70, blue: 0.25), filename: "MorningDashboard.shortcut"),
    .init(id: "clipboard", name: "Clipboard Cleaner", category: "Utilities",
          description: "Quick actions for copied text.", symbol: "doc.on.clipboard.fill",
          tint: Color(red: 0.25, green: 0.67, blue: 0.88), filename: "ClipboardCleaner.shortcut"),
    .init(id: "water", name: "Water Reminder", category: "Lifestyle",
          description: "A simple hydration reminder setup.", symbol: "drop.fill",
          tint: Color(red: 0.20, green: 0.72, blue: 0.83), filename: "WaterReminder.shortcut"),
    .init(id: "wifi", name: "Wi-Fi Details", category: "Utilities",
          description: "Open a handy network settings checklist.", symbol: "wifi",
          tint: Color(red: 0.28, green: 0.72, blue: 0.56), filename: "WiFiDetails.shortcut")
]

struct ShopView: View {
    @State private var searchText = ""
    @State private var selectedCategory = "All"
    @State private var showingInfo = false
    @State private var selectedItem: ShortcutItem?

    private let categories = ["All", "Productivity", "Utilities", "Lifestyle"]
    private let sky = Color(red: 0.72, green: 0.91, blue: 0.98)

    private var filteredItems: [ShortcutItem] {
        catalog.filter {
            (selectedCategory == "All" || $0.category == selectedCategory) &&
            (searchText.isEmpty || $0.name.localizedCaseInsensitiveContains(searchText) ||
             $0.description.localizedCaseInsensitiveContains(searchText))
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [sky, Color(red: 0.88, green: 0.97, blue: 0.94), .white],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    header
                    searchBar
                    categoryPicker
                    featuredCard

                    HStack {
                        Text("Explore shortcuts")
                            .font(.system(size: 23, weight: .bold, design: .rounded))
                            .foregroundStyle(Color(red: 0.08, green: 0.30, blue: 0.40))
                        Spacer()
                        Text("\(filteredItems.count) ITEMS")
                            .font(.system(size: 10, weight: .heavy, design: .rounded))
                            .tracking(1.2)
                            .foregroundStyle(.white)
                            .padding(.horizontal, 11).padding(.vertical, 7)
                            .background(.blue.opacity(0.55), in: Capsule())
                    }

                    LazyVStack(spacing: 13) {
                        ForEach(filteredItems) { item in
                            ShortcutCard(item: item) { selectedItem = item }
                        }
                    }

                    footer
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
                .padding(.bottom, 32)
            }
        }
        .sheet(item: $selectedItem) { item in
            ShortcutDetailView(item: item)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
        .alert("Shortcuts Shop", isPresented: $showingInfo) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("A community-style catalog for Apple Shortcuts. Add your own .shortcut files to the app bundle to make downloads available.")
        }
    }

    private var header: some View {
        HStack(alignment: .center) {
            VStack(alignment: .leading, spacing: 4) {
                Text("SHORTCUTS")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(Color(red: 0.08, green: 0.43, blue: 0.56))
                Text("Shop")
                    .font(.system(size: 38, weight: .black, design: .rounded))
                    .foregroundStyle(Color(red: 0.04, green: 0.28, blue: 0.39))
                Text("Little automations. Big possibilities.")
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundStyle(.black.opacity(0.55))
            }
            Spacer()
            Button { showingInfo = true } label: {
                Image(systemName: "info")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 45, height: 45)
                    .background(
                        LinearGradient(colors: [.cyan, .blue.opacity(0.8)],
                                       startPoint: .topLeading, endPoint: .bottomTrailing),
                        in: Circle()
                    )
                    .overlay(Circle().stroke(.white.opacity(0.85), lineWidth: 2))
                    .shadow(color: .blue.opacity(0.22), radius: 8, y: 4)
            }
            .buttonStyle(.plain)
        }
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(.blue.opacity(0.7))
            TextField("Search the shop...", text: $searchText)
                .font(.system(size: 15, weight: .medium, design: .rounded))
        }
        .padding(15)
        .background(.white.opacity(0.76), in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white, lineWidth: 2))
        .shadow(color: .blue.opacity(0.08), radius: 10, y: 5)
    }

    private var categoryPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                ForEach(categories, id: \.self) { category in
                    Button { selectedCategory = category } label: {
                        Text(category)
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundStyle(selectedCategory == category ? .white : .blue.opacity(0.8))
                            .padding(.horizontal, 15).padding(.vertical, 10)
                            .background {
                                Capsule().fill(
                                    selectedCategory == category
                                    ? AnyShapeStyle(LinearGradient(colors: [.cyan, .blue],
                                                                   startPoint: .topLeading, endPoint: .bottomTrailing))
                                    : AnyShapeStyle(.white.opacity(0.68))
                                )
                            }
                            .overlay(Capsule().stroke(.white, lineWidth: 1.5))
                        }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var featuredCard: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 26)
                .fill(LinearGradient(colors: [Color(red: 0.12, green: 0.68, blue: 0.82),
                                               Color(red: 0.18, green: 0.78, blue: 0.65)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
            Circle().fill(.white.opacity(0.13)).frame(width: 150).offset(x: 220, y: -38)
            Circle().fill(.white.opacity(0.12)).frame(width: 85).offset(x: 265, y: 52)
            VStack(alignment: .leading, spacing: 9) {
                Text("WELCOME TO THE FUTURE")
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .tracking(1.5)
                    .foregroundStyle(.white.opacity(0.85))
                Text("Make your iPhone\nwork smarter.")
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Discover useful automations.")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.9))
            }
            .padding(21)
        }
        .frame(height: 165)
        .overlay(RoundedRectangle(cornerRadius: 26).stroke(.white.opacity(0.8), lineWidth: 2))
        .shadow(color: .cyan.opacity(0.22), radius: 14, y: 7)
    }

    private var footer: some View {
        HStack {
            Image(systemName: "leaf.fill")
            Text("Made for curious minds")
            Spacer()
            Text("V1.0")
        }
        .font(.system(size: 10, weight: .bold, design: .rounded))
        .foregroundStyle(.blue.opacity(0.55))
        .padding(.top, 8)
    }
}

struct ShortcutCard: View {
    let item: ShortcutItem
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 17)
                        .fill(LinearGradient(colors: [item.tint.opacity(0.8), item.tint],
                                             startPoint: .topLeading, endPoint: .bottomTrailing))
                    Image(systemName: item.symbol)
                        .font(.system(size: 24, weight: .semibold))
                        .foregroundStyle(.white)
                        .shadow(color: .black.opacity(0.15), radius: 2, y: 2)
                }
                .frame(width: 58, height: 58)
                .overlay(RoundedRectangle(cornerRadius: 17).stroke(.white, lineWidth: 2))

                VStack(alignment: .leading, spacing: 4) {
                    Text(item.name)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(Color(red: 0.08, green: 0.29, blue: 0.39))
                    Text(item.description)
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(.black.opacity(0.52))
                        .lineLimit(2)
                    Text(item.category.uppercased())
                        .font(.system(size: 9, weight: .heavy, design: .rounded))
                        .tracking(1)
                        .foregroundStyle(.teal)
                }
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.blue.opacity(0.5))
            }
            .padding(13)
            .background(.white.opacity(0.78), in: RoundedRectangle(cornerRadius: 22))
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white, lineWidth: 2))
            .shadow(color: .blue.opacity(0.07), radius: 9, y: 4)
        }
        .buttonStyle(.plain)
    }
}

struct ShortcutDetailView: View {
    let item: ShortcutItem
    @Environment(\.dismiss) private var dismiss
    @State private var showMissingFile = false

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.77, green: 0.94, blue: 0.98), .white],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 17) {
                RoundedRectangle(cornerRadius: 20)
                    .fill(item.tint.gradient)
                    .frame(width: 76, height: 76)
                    .overlay(Image(systemName: item.symbol).font(.system(size: 32)).foregroundStyle(.white))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white, lineWidth: 2))
                Text(item.name)
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .foregroundStyle(.blue.opacity(0.85))
                Text(item.description)
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.black.opacity(0.6))
                if let shortcutURL = Bundle.main.url(
                    forResource: item.filename.replacingOccurrences(of: ".shortcut", with: ""),
                    withExtension: "shortcut"
                ) {
                    ShareLink(item: shortcutURL) {
                        Label("Get Shortcut", systemImage: "arrow.down.circle.fill")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(16)
                            .background(LinearGradient(colors: [.cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing),
                                        in: Capsule())
                            .overlay(Capsule().stroke(.white, lineWidth: 2))
                    }
                } else {
                    Button { showMissingFile = true } label: {
                        Label("Get Shortcut", systemImage: "arrow.down.circle.fill")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(16)
                            .background(LinearGradient(colors: [.cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing),
                                        in: Capsule())
                            .overlay(Capsule().stroke(.white, lineWidth: 2))
                    }
                    .buttonStyle(.plain)
                }
                Button("Close") { dismiss() }
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(.blue)
            }
            .padding(28)
        }
        .alert("Shortcut file not added yet", isPresented: $showMissingFile) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("This catalog entry is a demo. Add a real, exported .shortcut file to the Xcode project bundle before enabling downloads.")
        }
    }
}
