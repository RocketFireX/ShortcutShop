import SwiftUI

@main
struct ShortcutsShopApp: App {
    var body: some Scene {
        WindowGroup {
            ShopView()
                .preferredColorScheme(.light)
        }
    }
}
